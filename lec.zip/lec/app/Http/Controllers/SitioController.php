<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class SitioController extends Controller
{
   //
   public function index()
{
   echo "Hola Mundo";
}
public function saludar(Request $request, $nombre)
{
   echo "Hello" . $nombre;
}

}